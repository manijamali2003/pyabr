using System;

namespace MyWelcomeApp
{
    public class MainApp
    {
        public static void Main (string[] args)
        {
            Console.WriteLine ("Hello World!");
        }
    }
}