
# Pyabr cloud computing software

In the name of God, the Compassionate, the Merciful

Pyabr &copy; 2020 Mani Jamali. Free Software GNU General Public License v3.0

### What is Pyabr?
Pyabr is a cloud computing software for managing the cloud hosts, It was written in Python and compiled by CPython
You can develop your program in Pyabr with Standard Cloud Software Library (libabr) or native Python, C/C++, C#, Java, etc