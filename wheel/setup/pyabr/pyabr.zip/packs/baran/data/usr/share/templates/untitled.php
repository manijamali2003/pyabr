<!DOCTYPE HTML>
<html>
    <head>
        <title>Hello Page</title>
        <meta charset="utf-8"/>
    </head>
    <body>
        <?php echo "<p>Hello World!</p>";?>
    </body>
</html>